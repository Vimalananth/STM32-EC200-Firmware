/**
 * pump-telemetry — AWS Lambda
 *
 * Triggered by AWS IoT Core Rules Engine on topic: pump/#
 * IoT Rule SQL:
 *   SELECT *, topic() as topic_name FROM 'pump/#'
 *
 * Writes device telemetry from MQTT → Firebase Realtime Database.
 * Mirrors the MQTT→Firebase logic from bridge.js (Railway).
 *
 * Environment variables (set in Lambda console):
 *   FIREBASE_SERVICE_ACCOUNT  — Firebase service account JSON string
 *   FIREBASE_DB_URL           — Firebase Realtime DB URL
 */

const admin = require('firebase-admin');

// ── Firebase init (runs once per Lambda container) ────────────────────────────
let firebaseReady = false;
function initFirebase() {
  if (firebaseReady) return;
  const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
  admin.initializeApp({
    credential:  admin.credential.cert(serviceAccount),
    databaseURL: process.env.FIREBASE_DB_URL ||
                 'https://pump-controller-4398d-default-rtdb.firebaseio.com'
  });
  firebaseReady = true;
}

// ── Topic → Firebase routing map ──────────────────────────────────────────────
// method: 'set'  → db.ref(fbPath).set(payload)    (overwrites — latest state)
// method: 'push' → db.ref(fbPath).push(payload)   (appends — time-series log)
const TOPIC_MAP = {
  // ── site01 ──
  'pump/01/status':       { fbPath: 'sites/site01/line01/pump01/status',     method: 'set'  },
  'pump/01/alerts':       { fbPath: 'sites/site01/line01/pump01/alerts',     method: 'push' },
  'pump/01/log':          { fbPath: 'sites/site01/line01/pump01/alerts',     method: 'push' },
  'pump/01/vlog':         { fbPath: 'sites/site01/line01/pump01/logs',       method: 'push' },
  'pump/01/ota/status':   { fbPath: 'sites/site01/line01/pump01/ota_status', method: 'set'  },
  'pump/01/slave_status': { fbPath: 'sites/site01/line02/pump01/status',     method: 'set'  },
  'pump/01/slave_vlog':   { fbPath: 'sites/site01/line02/pump01/logs',       method: 'push' },
  'pump/01/slave_alerts': { fbPath: 'sites/site01/line02/pump01/alerts',     method: 'push' },

  'pump/02/status':       { fbPath: 'sites/site01/line01/pump02/status',     method: 'set'  },
  'pump/02/alerts':       { fbPath: 'sites/site01/line01/pump02/alerts',     method: 'push' },
  'pump/02/log':          { fbPath: 'sites/site01/line01/pump02/alerts',     method: 'push' },
  'pump/02/vlog':         { fbPath: 'sites/site01/line01/pump02/logs',       method: 'push' },
  'pump/02/ota/status':   { fbPath: 'sites/site01/line01/pump02/ota_status', method: 'set'  },

  // ── site02 ──
  'pump/03/status':       { fbPath: 'sites/site02/line01/pump01/status',     method: 'set'  },
  'pump/03/alerts':       { fbPath: 'sites/site02/line01/pump01/alerts',     method: 'push' },
  'pump/03/log':          { fbPath: 'sites/site02/line01/pump01/alerts',     method: 'push' },
  'pump/03/vlog':         { fbPath: 'sites/site02/line01/pump01/logs',       method: 'push' },
  'pump/03/ota/status':   { fbPath: 'sites/site02/line01/pump01/ota_status', method: 'set'  },
  'pump/03/slave_status': { fbPath: 'sites/site02/line02/pump01/status',     method: 'set'  },
  'pump/03/slave_vlog':   { fbPath: 'sites/site02/line02/pump01/logs',       method: 'push' },
  'pump/03/slave_alerts': { fbPath: 'sites/site02/line02/pump01/alerts',     method: 'push' },

  'pump/04/status':       { fbPath: 'sites/site02/line01/pump02/status',     method: 'set'  },
  'pump/04/alerts':       { fbPath: 'sites/site02/line01/pump02/alerts',     method: 'push' },
  'pump/04/log':          { fbPath: 'sites/site02/line01/pump02/alerts',     method: 'push' },
  'pump/04/vlog':         { fbPath: 'sites/site02/line01/pump02/logs',       method: 'push' },
  'pump/04/ota/status':   { fbPath: 'sites/site02/line01/pump02/ota_status', method: 'set'  },
};

// ── Timestamp normalisation ───────────────────────────────────────────────────
// Firmware sends ts in Unix seconds (~1.75B). Firebase needs ms (~1.75T).
function normaliseTs(payload) {
  if (payload.ts && payload.ts > 0 && payload.ts < 1e12) {
    payload.ts = payload.ts * 1000;
  }
  if (!payload.ts) {
    payload.ts = Date.now();
  }
  return payload;
}

// ── Lambda handler ─────────────────────────────────────────────────────────────
exports.handler = async (event) => {
  initFirebase();
  const db = admin.database();

  // IoT Rule injects topic_name via topic() function in the SQL statement
  const topic = event.topic_name;
  if (!topic) {
    console.error('[ERROR] No topic_name in event:', JSON.stringify(event));
    return { statusCode: 400, body: 'Missing topic_name' };
  }

  const route = TOPIC_MAP[topic];
  if (!route) {
    console.log(`[SKIP] No route for topic: ${topic}`);
    return { statusCode: 200, body: 'No route' };
  }

  // Remove internal topic_name field before writing to Firebase
  const { topic_name, ...payload } = event;
  normaliseTs(payload);

  console.log(`[ROUTE] ${topic} → ${route.fbPath} (${route.method})`);

  try {
    const ref = db.ref(route.fbPath);
    if (route.method === 'set') {
      await ref.set(payload);
    } else {
      await ref.push(payload);
    }
    console.log(`[OK] Written to ${route.fbPath}`);
    return { statusCode: 200, body: 'OK' };
  } catch (err) {
    console.error(`[ERROR] Firebase write failed: ${err.message}`);
    throw err;  // Lambda retries on error
  }
};
